<?php 

require "vendor/autoload.php";
require "core/bootstrp.php";

// require "controllers/index.controller.php";


 Router::load("routes.php")->direct(Request::uri(),$_SERVER['REQUEST_METHOD']); //Request::uri()
?> 
