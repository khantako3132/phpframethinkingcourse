<?php 

// $router->get("","PagesController@home");
// $router->get("about","PagesController@about");
// $router->get("contact","PagesController@contact");
// $router->get("order","PagesController@order");
// $router->get("customer","PagesController@customer");

// $router->post("names","PagesController@createUser");

// $router->get("index","UserController@index");
use controllers\PagesController;
use controllersUse\UserController;
$router->get("",[PagesController::class,"home"]);
$router->get("about",[PagesController::class,"about"]);
$router->get("contact",[PagesController::class,"contact"]);
$router->get("order",[PagesController::class,"order"]);
$router->get("customer",[PagesController::class,"customer"]);
$router->get("edit",[PagesController::class,"edit"]);
$router->get("index",[UserController::class,"index"]);
$router->post("names",[PagesController::class,"createUser"]);

?>