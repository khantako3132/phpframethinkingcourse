<?php 
return [
    'database' => [
        "username" => "admin",
        "password" => "123456",
        "dbName"    => "todo",
        "host"      => "mysql:host=localhost"
    ]
    ];


?>