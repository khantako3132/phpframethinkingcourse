<?php 
class Router{
    protected $routes = [
        "GET"   => [],
        "POST"  => []
    ];
    public function define($routes)
    {
       return $this->routes = $routes;
    }
    public static function load($filename){
        $router = new Router;
        require "routes.php";
        return $router;
    }
    public function get($uri,$controller){
        $this->routes['GET'] [$uri] = $controller;
    }
    public function post($uri,$controller){
        $this->routes['POST'] [$uri] = $controller;
    }
    public function direct($uri,$method){
        if(!array_key_exists($uri, $this->routes[$method])){
            die("404 not found error");
          
        }
        $explosion = $this->routes[$method][$uri];
        $this->callAction($explosion[0],$explosion[1]);
    }
    public function callAction($class,$method){
                $class =new $class;
                $class->$method();
    }
}

?>