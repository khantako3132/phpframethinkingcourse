<?php 
class queryBuilder{
    protected $pdo;
    public function __construct($pdo)
    {
        $this->pdo = $pdo;
    }
    public  function insert($dataArr,$table){
        $cols = implode(",",array_keys($dataArr));
        $getDataKey = array_keys($dataArr);
        $questionMarks = "";
        foreach($getDataKey as $key){
            $questionMarks .= "?,";
        };
        $questionMarks = rtrim($questionMarks,",");
        $sql = "insert into $table ($cols) values ($questionMarks)";

         $statement = $this->pdo->prepare($sql);

        $getDataValues = array_values($dataArr);

        $statement->execute($getDataValues);
    }

    public function delete($dataArr,$table){
        $cols   = implode(",",array_keys($dataArr));
        $questionMarks = "";
        $getDataKey = array_keys($dataArr);
        foreach($getDataKey as $key){
            $questionMarks .= "?,";
        }
        $questionMarks = rtrim($questionMarks,",");
        $sqlDelete = "delete from $table where $cols = $questionMarks";
        $statement = $this->pdo->prepare($sqlDelete);
        $getDataValues = array_values($dataArr);
        $statement->execute($getDataValues);
    }
    public function selectAll($table){
        $statement = $this->pdo->prepare("Select * from $table");
        $statement->execute();
        return $statement->fetchAll(PDO::FETCH_OBJ);  
    }
}

?>