<?php require "partials/header.php"?>

<?php foreach($user as $use):?>
    <?= $use->name?>
<?php endforeach?>
<h1>Add Your Name to database.</h1>

<form action="/names" method="POST">
  
    <input type="text" name="name">
    <input type="submit" value="submit">
</form>

<!-- deleting  -->
<!-- <form action="/names" method="POST">
  
    <input type="text" name="name">
    <input type="submit" value="submit">
</form> -->


<?php require "partials/footer.php"?>