<?php 

view("customer")?>