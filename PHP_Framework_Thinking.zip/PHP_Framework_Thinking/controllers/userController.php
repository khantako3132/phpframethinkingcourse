<?php 
namespace controllersUse;
use core\App;
class UserController{
    public function index() {
        return view("index",[
            "user" => App::get('database')->selectAll('user')
        ]);
    }
}

?>