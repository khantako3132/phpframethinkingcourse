<?php 
  
  view('contact')
?>