<?php 
view('about');

?>