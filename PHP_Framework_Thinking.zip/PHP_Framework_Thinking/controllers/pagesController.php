<?php 
namespace controllers;
use core\App;

class PagesController{
    public function home(){
        $user = App::get('database')->selectAll("user");

    view("index",[
    "user" => $user
    ]);
    }
    public function about(){
        view('about');
    }
    public function contact(){
        view('contact');
    }
    public function order(){
        view('order');
    }
    public function customer(){
        view('customer');
    }
    public function edit(){
        view('edit');
    }
    public function createUser(){
        App::get('database')->insert([
            "name"=>request('name')
        ],"user");
        // $App::get('database')->delete([
        //     "name"  => $_POST['name']
        // ],"user");
       redirect("/");
    }
}

?>